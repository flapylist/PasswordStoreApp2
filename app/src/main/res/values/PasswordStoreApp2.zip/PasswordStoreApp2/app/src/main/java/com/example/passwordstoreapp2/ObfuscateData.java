package com.example.passwordstoreapp2;


public class ObfuscateData {

    public static String getDBPassword(){
        return "!Zpr,x)F6f^>v8`G";
    }
}
