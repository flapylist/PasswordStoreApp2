package com.example.passwordstoreapp2;

public class DeleteEvent {
    public int position;
            public DeleteEvent(int position){
        this.position=position;
            }
}
